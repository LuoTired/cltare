package com.zh.springbootmultidatasource.service;

/**
 * @author zhanghang
 * @date 2019/6/6
 */
public interface BookProductService {

    void bookProduct(Integer productId,Integer userId);

}
