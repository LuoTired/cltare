package com.zh.springbootswagger.model;

import lombok.Data;

/**
 * @author zhanghang
 * @date 2019/5/29
 */
@Data
public class User {

    private Integer id;

    private String name;

    private Integer age;

}
