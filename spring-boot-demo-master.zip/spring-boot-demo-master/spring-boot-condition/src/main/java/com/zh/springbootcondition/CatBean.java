package com.zh.springbootcondition;

import lombok.extern.slf4j.Slf4j;

/**
 * @author zhanghang
 * @date 2019/5/29
 */
@Slf4j
public class CatBean {

    public void say(){
        log.info("---------------------------I am a cat:喵喵喵-----------------------------------");
    }
}
