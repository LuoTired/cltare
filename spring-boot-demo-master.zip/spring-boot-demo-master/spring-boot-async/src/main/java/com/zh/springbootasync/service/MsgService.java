package com.zh.springbootasync.service;

/**
 * @author zhanghang
 * @date 2019/6/17
 */
public interface MsgService {
    void sendMsg();
}
