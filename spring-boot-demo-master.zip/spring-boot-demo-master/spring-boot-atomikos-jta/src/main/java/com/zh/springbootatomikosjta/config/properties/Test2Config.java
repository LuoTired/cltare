package com.zh.springbootatomikosjta.config.properties;

import lombok.Data;

/**
 * @author zhanghang
 * @date 2019/6/10
 */
@Data
public class Test2Config {

    private String jdbcUrl;

    private String username;

    private String password;

}
