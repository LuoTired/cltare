package com.zh.springbootmongodb.base.constance;

/**
 * @author zhanghang
 * @date 2019/6/14
 */
public class DateConstance {

    public static final String FORMATTER_YYYY_MM_DD = "yyyy/MM/dd";
}
