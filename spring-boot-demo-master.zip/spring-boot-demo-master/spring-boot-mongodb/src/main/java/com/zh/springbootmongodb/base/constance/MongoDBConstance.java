package com.zh.springbootmongodb.base.constance;

/**
 * @author zhanghang
 * @date 2019/6/14
 */
public class MongoDBConstance {

    public static final String COLLECTION_NAME_PRE_APP_VISIT_LOG = "app_visit_log_";
}
