package com.zh.springbootcommand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCommandApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootCommandApplication.class, args);
    }

}
