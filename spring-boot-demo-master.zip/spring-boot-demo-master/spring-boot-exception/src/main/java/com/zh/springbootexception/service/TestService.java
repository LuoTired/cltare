package com.zh.springbootexception.service;

import com.zh.springbootexception.dto.Result;

/**
 * @author zhanghang
 * @date 2019/6/5
 */
public interface TestService {
    Result test(Integer index);
}
